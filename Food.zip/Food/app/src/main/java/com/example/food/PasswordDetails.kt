package com.example.food

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView


class PasswordDetails : AppCompatActivity() {

    lateinit var  etPEmailAddress: TextView
    lateinit var etPMobile: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_password_details)

        etPEmailAddress=findViewById(R.id.etPEmailAddress)
        etPMobile=findViewById(R.id.etPMobile)

        if(intent!=null) {
            etPEmailAddress.text =intent.getStringExtra("Email")
            etPMobile.text=intent.getStringExtra("Mobile")
        }
    }
}
