package com.example.food

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_forgot_password.*

class ForgotPassword : AppCompatActivity() {
    lateinit var etFEmailAddress: EditText
    lateinit var etFMobile: EditText
    lateinit var btnFNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)


        etFEmailAddress=findViewById(R.id.etFEmailAddress)
        etFMobile=findViewById(R.id.etFMobile)
        btnFNext=findViewById(R.id.btnFNext)

        var s:String
        btnFNext.setOnClickListener {
            val intent= Intent(this@ForgotPassword,PasswordDetails::class.java)
            s=etFEmailAddress.text.toString()
            intent.putExtra("Email",s)
            s=etFMobile.text.toString()
            intent.putExtra("Mobile",s)
            startActivity(intent)
        }
    }
}
