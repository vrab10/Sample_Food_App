package com.example.food

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class Greeting : AppCompatActivity() {

    lateinit var txtGNumber: TextView
    lateinit var txtGPassword: TextView
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_greeting)

    txtGNumber=findViewById(R.id.txtGNumber)
    txtGPassword=findViewById(R.id.txtGPassword)
    sharedPreferences=getSharedPreferences(getString(R.string.food_files), Context.MODE_PRIVATE)
    txtGNumber.text=sharedPreferences.getString("Mobile","New Customer")
    txtGPassword.text=sharedPreferences.getString("Password",null)
    }
}
