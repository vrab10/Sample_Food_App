package com.example.food

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class SignUp : AppCompatActivity() {

    lateinit var etName: EditText
    lateinit var etEmailAddress: EditText
    lateinit var etMobile: EditText
    lateinit var etDelivery: EditText
    lateinit var etPass: EditText
    lateinit var etCPass: EditText
    lateinit var btnRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_sign_up)

        title="Register Yourself"

        etName=findViewById(R.id.etName)
        etEmailAddress=findViewById(R.id.etEmailAddress)
        etMobile=findViewById(R.id.etMobile)
        etDelivery=findViewById(R.id.etDelivery)
        etPass=findViewById(R.id.etPass)
        etCPass=findViewById(R.id.etCPass       )//need to add functionality and relate with password
        btnRegister=findViewById(R.id.btnRegister)

        var s: String
        var st: String

        btnRegister.setOnClickListener {
        val intent= Intent(this@SignUp,Registration::class.java)
            s=etName.text.toString()
        intent.putExtra("Name",s)
            s=etEmailAddress.text.toString()
        intent.putExtra("Email",s)
            s=etMobile.text.toString()
        intent.putExtra("Mobile",s)
            s=etDelivery.text.toString()
        intent.putExtra("Delivery",s)
            s=etPass.text.toString()
            st=etCPass.text.toString()

            if(s == st){
                intent.putExtra("Password",s)
                startActivity(intent)
            }
            else{
                Toast.makeText(this@SignUp,"Passwords did not match",Toast.LENGTH_LONG).show()
            }


}
    }
}
