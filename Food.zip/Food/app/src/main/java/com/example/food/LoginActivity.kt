package com.example.food

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    lateinit var btnLogin: Button
    lateinit var etMobile: EditText
    lateinit var etPassword: EditText
    lateinit var txtForgot: TextView
    lateinit var txtAccount: TextView
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences=getSharedPreferences(getString(R.string.food_files),Context.MODE_PRIVATE)
        val b=sharedPreferences.getBoolean("Logged",false)

        setContentView(R.layout.activity_login)

        btnLogin=findViewById(R.id.btnLogin)
        etMobile=findViewById(R.id.etMobile)
        etPassword=findViewById(R.id.etPassword)
        txtForgot=findViewById(R.id.txtForgot)
        txtAccount=findViewById(R.id.txtAccount)

        var s:String
        var p:String

        if(b){
            val intent=Intent(this@LoginActivity,Greeting::class.java)
            startActivity(intent)
            finish()
        }

        btnLogin.setOnClickListener {
            s=etMobile.text.toString()
            p=etPassword.text.toString()

            if(s!="" && p!="") {
                val intent = Intent(this@LoginActivity, Greeting::class.java)
                save(s,p)
                startActivity(intent)
            }else{
                Toast.makeText(this@LoginActivity,"Please enter details",Toast.LENGTH_LONG).show()
            }

        }

        txtForgot.setOnClickListener {
            val intent=Intent(this@LoginActivity,ForgotPassword::class.java)
             startActivity(intent)
        }

        txtAccount.setOnClickListener {
            val intent=Intent(this@LoginActivity,SignUp::class.java)
            startActivity(intent)
        }

    }

    override fun onPause() {
        super.onPause()
        finish()
    }
    fun save(s: String,p: String){
        sharedPreferences.edit().putBoolean("Logged",true).apply()
        sharedPreferences.edit().putString("Mobile",s).apply()
        sharedPreferences.edit().putString("Password",p).apply()
    }

}
