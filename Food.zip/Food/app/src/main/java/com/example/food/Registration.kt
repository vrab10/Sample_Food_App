package com.example.food

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_registration.*

class Registration : AppCompatActivity() {
    lateinit var etRName: TextView
    lateinit var etREmailAddress: TextView
    lateinit var etRMobile: TextView
    lateinit var etRDelivery: TextView
    lateinit var etRPass: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        etRName=findViewById(R.id.etRName)
        etREmailAddress=findViewById(R.id.etREmailAddress)
        etRMobile=findViewById(R.id.etRMobile)
        etRDelivery=findViewById(R.id.etRDelivery)
        etRPass=findViewById(R.id.etRPass)

        if(intent!=null){
            etRName.text=intent.getStringExtra("Name")
            etREmailAddress.text=intent.getStringExtra("Email")
            etRMobile.text=intent.getStringExtra("Mobile")
            etRDelivery.text=intent.getStringExtra("Delivery")
            etRPass.text=intent.getStringExtra("Password")
        }
    }
}
